import React from "react";

export default function About_home() {
  return (
    <div className="About-home">
      <div className="first-sec">
        <h1>About Us</h1>
        <h4>
          Business planning, Strategy and Execution. A problem-solving
          philosophy that leads to products people actually want to use.
        </h4>
        <p>
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. Animi
          recusandae, ducimus vel rerum accusamus odit provident nobis ratione
          quisquam obcaecati atque fuga maiores! Tenetur aspernatur alias unde
          facilis eveniet? Eius! Lorem ipsum dolor sit amet, Fugit ipsam nostrum
          minus alias, expedita.
        </p>
      </div>
      <div className="img-sec">
        <img
          src="https://demo.w3layouts.com/demos_new/template_demo/29-02-2020/captivate-liberty-demo_Free/232105078/web/assets/images/about.png"
          alt="busness lady"
        />
      </div>
    </div>
  );
}
