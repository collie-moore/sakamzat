## Sakamzat.

This is a fully responsive business oriented website designed by w3 Layouts and built by me. This was built with SASS, JSX, React, React-Hooks, React-Router and hosted at https://sakamzat.co.ke
"# sakamzat" 
